# v4 upgrade — what changed and how to install

## Install (4 files, ~3 minutes)

Replace these in your repo, then run the workflow:

| File | Why |
|---|---|
| `scraper/scrape.py` | enrichment, fit scoring, YC adapter, 10 new boards |
| `config.json` | fit profile (your weights), Boston metro |
| `boards.json` | 29 boards, up from 19 |
| `docs/index.html` | new filters, fit ranking, richer cards |

**Do not delete `data/seen.json` this time.** The job identity scheme is unchanged in
v4, so your "first seen" history and NEW badges carry over. The new boards will
produce one larger-than-usual notification on the first run — that is expected, and
the issue body now caps itself at 30 roles.

## New boards (19 → 29)

**Getro** (parser already proven): Craft Ventures, 8VC, Sapphire Ventures, Thrive
Capital, Scale Venture Partners, and **Getro Community** — a cross-network
aggregator that includes Pear VC, SignalFire and others in one board.

**Consider**: Felicis, GV (Google Ventures), Initialized Capital.

**Y Combinator** (new adapter): `ycombinator.com/jobs` is public — no login, unlike
Work at a Startup — and publishes salary on most listings. Scraped across the
operations / finance / product / sales role pages.

Not added: **Founders Fund** (no public aggregated board) and **LinkedIn** (no
public API; scraping violates their terms).

## New per-role data

Each role now carries, where the board publishes it:

- **salary** min/max (YC almost always; Getro/Consider sometimes)
- **funding stage** — Seed → Series D+ / Growth / Public
- **company size** — headcount bucket (`51-200` etc.)
- **seniority + typical years of experience** — inferred from the title, with
  "Chief of Staff" special-cased so it is not misread as C-suite or "Staff Engineer"
- **remote OK**, and **YC batch** for YC roles

Anything a board does not publish is simply absent — filters for empty fields hide
themselves rather than silently dropping roles.

## Fit score (0–100)

Every role is scored against the profile in `config.json → fit_profile`, built from
your resume: post-MBA level, strategy/GTM background, B2B SaaS, SF/NYC/Boston.
The score is plain addition — each point is attributable to one rule, and the
reasons render under every card (`Chief of Staff +18; Manager-level +10; …`).

Roughly: base 35, then role type (+18 CoS … +3 RevOps), seniority (+12 Principal,
+10 Manager, −12 Associate, −45 Intern), stage (+8 Series B/C, −8 Public), size
(+8 51-200, −10 5k+), metro (+8 SF, +7 NYC, +5 Boston), salary (+7 at/above $150k,
−12 well below), and +4 for GTM / founder's-office phrasing.

**Every number is a knob.** Disagree with any of it — edit the value in
`config.json` and the next run re-ranks. Want Austin weighted up, or Series A
treated as favourably as Series B? One number each.

## Dashboard

- **Sort by best fit** (default), newest, highest salary, or company
- New filters behind "More filters": seniority, funding stage, company size,
  minimum fit slider, minimum salary slider, "has salary", "remote OK", board
- **★ Saved only** view for your shortlist
- Fit bar + score on every card, with the reasoning underneath
- CSV export now includes fit, salary, stage, size, seniority and metro

## Tuning notes

- `fit_profile.metro_weights` includes **Boston at +5** — you are there now and HBS
  roles cluster locally. Delete the line if you do not want Boston roles surfaced.
- If too much noise appears, raise the **Min fit** slider to 60 and save that as
  your habitual view; the ranking does the triage for you.


---

# v4.1 addendum — precision tuning (added after the first full sweep)

The first deep run pulled **71,418 jobs** across the Consider boards (a16z alone
went from 100 to 16,373) and matched **907** roles. At that depth, precision
mattered more than recall, so v4.1 adds a **two-tier title filter**:

- **Hard exclusions** — tax, annuities, underwriting, ICQA, clinical/nursing:
  dropped always.
- **Soft exclusions** — domain-qualified ops roles that are a *different
  function*: product ops, legal ops, creative ops, workplace ops, supply-chain
  ops, annotation ops and similar. These drop **only when the title contains no
  strong-positive phrase**, so `Chief of Staff, Director of Legal Operations` and
  `Payments Business Operations` still come through.

Measured against the live 907 rows: **69 removed, 838 kept, zero false removals**
from Chief of Staff / BizOps / Founder's Office / Corp Dev.

Deliberately **kept**: sales ops, partner ops, channel ops and customer ops — all
adjacent to your Accenture GTM/partner-strategy background. The fit score ranks
them rather than the filter deleting them.

Also in v4.1: each board now **retries once after a 20-second pause** before being
marked failed. IVP dropped its connection mid-run on the last sweep; that class of
transient reset now self-heals.


---

# v4.2 — early-stage re-weighting (per your note)

Your stated preference is **Chief of Staff / Founder's Office at seed, Series A,
maybe Series B**. v4's weights did the opposite — they rewarded Series B/C and
penalised Seed. Inverted:

| | v4 | v4.2 |
|---|---|---|
| Seed | −5 | **+11** |
| Series A | +3 | **+12** |
| Series B | +8 | **+8** |
| Series C | +8 | **−2** |
| Series D+ | +5 | **−7** |
| Growth/Late | +1 | **−9** |
| Public | −8 | **−14** |

Company size follows the same logic (11-50 **+10**, 51-200 **+9**, 1-10 **+6**,
5k+ **−13**), Chief of Staff rises to **+22** and Founder's Office to **+21**, and
the salary target drops from $150k to **$130k** with a softer penalty — otherwise
the scoring would punish exactly the early-stage roles you want. "Founding" and
"first business hire" are now bonus title keywords.

Net effect: a seed-stage *Founding Chief of Staff* scores **100**; the same title
at a public company scores **49**.
